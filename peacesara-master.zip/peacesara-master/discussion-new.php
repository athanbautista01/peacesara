<?php
//Connect to MySQL
// require_once("database/connect.php");
//include the header
$title="Peacesara | Add New Discussion";
include("include/header.php");
?>
<hr>

<hr>
<?php
//include the header
include("include/footer.php");
?>