	<div class="cover-container">
        <div class="cover-container mastfoot">
          <div class="inner">
            <p>Copyright &copy; #PeaceHACK | <a href="#">Team Kinchana</a> 2016. All Rights Reserved</p>
          </div>
        </div>
      </div>

    </div>

  </div>

</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<!-- Bootstrap js -->
<!-- <script src="assets/bootstrap/js/bootstrap.min.js"></script> -->
<script src="assets/bootstrap/js/bootstrap.js"></script>
</body>
</html>